<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container mt-3">
  <h2>Registration  form</h2>
  <form action="" method="post">
    @csrf
    <div class="mb-3 mt-3">
      <label for="">Name</label>
      <input type="text" class="form-control" id="name" placeholder="Enter name" name="name">
    </div>
    <div class="mb-3">
      <label for="">city</label>
      <input type="text" class="form-control" id="city" placeholder="Enter city" name="city">
    </div>
    <div class="mb-3">
      <label for="">marks</label>
      <input type="number" class="form-control" id="number" placeholder="Enter marks" name="marks">
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
 
</div>
</body>
</html>
